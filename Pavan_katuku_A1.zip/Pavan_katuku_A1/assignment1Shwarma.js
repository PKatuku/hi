const Order = require("./assignment1Order");

const OrderState = Object.freeze({
    WELCOMING:   Symbol("welcoming"),
    Item: Symbol("Item"),
    SIZE:   Symbol("size"),
    TOPPINGS:   Symbol("toppings"),
    DRINKS:  Symbol("drinks")
});

module.exports = class ShwarmaOrder extends Order{
    constructor(){
        super();
        this.stateCur = OrderState.WELCOMING;
        this.sItem ="";
        this.sSize = "";
        this.sToppings = "";
        this.sDrinks = "";
        this.Icost = 0;
        this.scost = 0;
        this.Tcost = 0;
        this.Dcost=0;
        this.Total=0;
        this.subTotal=0;
        this.Tax=0;
    }
    handleInput(sInput){
        let aReturn = [];
        switch(this.stateCur){
            case OrderState.WELCOMING:
                this.stateCur = OrderState.Item;
                aReturn.push("Welcome to Mutton Mastan");
                aReturn.push("select your item?");
                aReturn.push('ChickenWrap ');
                aReturn.push('MuttonWrap ');
                aReturn.push('VegWrap ');
                break;
            case OrderState.Item:
                this.stateCur=OrderState.SIZE;
                this.sItem=sInput;
                if(sInput.toLowerCase()=="chickenwrap"){
                    this.Icost=8;
                }
                if(sInput.toLowerCase()=="muttonwrap"){
                    this.Icost=9;
                }
                if(sInput.toLowerCase()=="vegwrap"){
                    this.Icost=7;
                }
                aReturn.push("select your size");
                aReturn.push("Large");
                aReturn.push("Medium");
                aReturn.push("small");
                break;
            case OrderState.SIZE:
                this.stateCur = OrderState.TOPPINGS
                this.sSize = sInput;
                if(sInput.toLowerCase()=="large"){
                    this.scost=4;
                }
                if(sInput.toLowerCase()=="medium"){
                    this.scost=2;
                }
                if(sInput.toLowerCase()=="small"){
                    this.scost=0;
                }
                aReturn.push("What toppings would you like?");
                aReturn.push("crispyonions");
                aReturn.push("olives");
                break;
            case OrderState.TOPPINGS:
                this.stateCur = OrderState.DRINKS
                this.sToppings = sInput;
                if(sInput.toLowerCase()=="crispyonions"){
                    this.Tcost=1;
                }
                if(sInput.toLowerCase()=="olives"){
                    this.Tcost=2;
                }
                aReturn.push("Would you like drinks with that?");
                aReturn.push("Yes or no")
                break;
            case OrderState.DRINKS:
                this.isDone(true);
                if(sInput.toLowerCase() != "no"){
                    this.Dcost=2;
                    this.sDrinks = sInput;
                }
                aReturn.push("Thank-you for your order of");
                this.subTotal=this.Icost+this.Tcost+this.scost+this.Dcost;
                this.Tax=this.subTotal*0.13;
                this.Total=this.Tax+this.subTotal;
                aReturn.push(`${this.sSize} ${this.sItem} with ${this.sToppings}`);
                aReturn.push(`Sub Total=$ ${this.subTotal}`)
                aReturn.push(`Tax=$ ${this.Tax}`)
                aReturn.push(`Total=$ ${this.Total}`)
                if(this.sDrinks){
                    aReturn.push(this.sDrinks);
                }
                let d = new Date(); 
                d.setMinutes(d.getMinutes() + 20);
                aReturn.push(`Please pick it up at ${d.toTimeString()}`);
                break;
        }
        return aReturn;
    }
}